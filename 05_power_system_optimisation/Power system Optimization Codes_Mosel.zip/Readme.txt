================================================================
  Assignment 2, Part A
  Operational Dispatch Problem
  ================================================================

  USAGE
  -----
  Run all tasks in sequence with:
      mosel partA.mos

  Tasks run in order: A1 --> A2 --> A3 --> A4.
  All results are printed to the console/exported to Solution_PartA.txt.

  DATA FILES REQUIRED
  ----------------------------------------------------
    partA_data.dat  -- scalar parameters and slice bounds (TB, TE)
    Y15_dem.dat     -- demand time series [MW], 17520 half-hours
    Y15_win.dat     -- wind   time series [MW], 17520 half-hours
    Y15_sol.dat     -- solar  time series [MW], 17520 half-hours

  MODEL SUMMARY
  -----------------------------------------
  Sets:
    G = {Coal, CCGT, Nucl, Wind, Solar}
    T = TB..TE  (Slice-O: 443..1104, cyclic)

  Objective (average hourly OPEX [£k/h]):
    min  (Ht/|T|) * sum_t [ sum_g CG_g*pG_gt  +  CCH*pCH_t ]

  Key constraints:
    Power balance:   sum_g pG_gt + pDC_t - pCH_t - shed_t = PD_t
    Wind limit:      pG_Wind,t  <= PW_t
    Solar limit:     pG_Solar,t <= PS_t
    PHES energy bal: q_t = q_nxt(t) + eta*Ht*pCH_t - Ht*pDC_t  (cyclic)
    CO2 limit:       (Ht/|T|)*sum_t sum_g Ug_g*pG_gt <= U+  [A2-A3 only]
    
    
  ================================================================
  Assignment 2, Part B
  Joint Investment and Operational Problem
  ================================================================

  USAGE
  -----
  Run all tasks in sequence with:
      mosel partB.mos

  Tasks run in order: B1 --> B2 --> B3 --> B4 --> B5.
  All results are printed to the console /exported to Solution_PartB.txt.

  DATA FILES REQUIRED (same folder as this .mos file)
  ----------------------------------------------------
    partB_data.dat  -- scalar parameters and slice bounds (TB=1, TE=17520)
    Y15_dem.dat     -- demand time series [MW], 17520 half-hours
    Y15_win.dat     -- wind   time series [MW], 17520 half-hours
    Y15_sol.dat     -- solar  time series [MW], 17520 half-hours

  MODEL SUMMARY (matches LaTeX formulation)
  -----------------------------------------
  Sets:
    G = {Coal, CCGT, Nucl, Wind, Solar}
    T = 1..17520  (Slice-I: full year, cyclic)

  Investment variables (continuous, lower-bounded):
    Pw -- wind power capacity  [GW],  Pw >= PGlo("Wind")
    Ps -- solar power capacity [GW],  Ps >= PGlo("Solar")
    Pp -- PHES power capacity  [GW],  Pp >= Pplo
    Q  -- PHES energy capacity [GWh], Q  >= Qlo

  Objective (average hourly total cost [£k/h]):
    min  KCPX_Wind*Pw + KCPX_Solar*Ps + KCPX_P*Pp + KCPX_Q*Q
         + (Ht/|T|) * sum_t [ sum_g CG_g*pG_gt  +  CCH*pCH_t ]

  Key constraints:
    Power balance:   sum_g pG_gt + pDC_t - pCH_t - shed_t = PD_t
    Wind limit:      pG_Wind,t  <= Pw * w_t   (linear: w_t is a parameter)
    Solar limit:     pG_Solar,t <= Ps * s_t
    PHES power:      pCH_t, pDC_t <= Pp
    PHES energy bal: q_t = q_nxt(t) + eta*Ht*pCH_t - Ht*pDC_t  (cyclic)
    PHES energy cap: q_t <= Q
    CO2 limit:       (Ht/|T|)*sum_t sum_g Ug_g*pG_gt <= U+  [B2-B3 only]
    